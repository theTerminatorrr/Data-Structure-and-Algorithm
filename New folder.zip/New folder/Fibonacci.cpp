#include<bits/stdc++.h>
using namespace std;

long long calls = 0;

long long fib_rec( int n )
{
    ++calls;

    if( n<=1 ) return n;

    return fib_rec( n-1 ) + fib_rec( n-2 );

}

int main ()
{
    int n;
    cout << "Enter the value of n: ";
    cin >> n;

    long long result = fib_rec(n);

    cout << "Fibonacci(" << n << ") = " << result << endl;
    return 0;
}
