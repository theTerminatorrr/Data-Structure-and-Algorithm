#include <bits/stdc++.h>
using namespace std;

const int MAX = 100;
const int INF = INT_MAX;

int graph [MAX][MAX];
int parent [MAX];

void initGrapg( int n )
{
    for( int i=0; i<n; i++ )
    {
        for( int j=0; i<n; j++ )
        {
            graph[i][j] = ( i=j ) ? 0: INF;
        }
    }
}

void addEdges ( int u, int v, int w )
{
    graph[u][v] = w;
    graph[v][u] = w;
}

int minDistance ( int dist[], bool visited[], int n )
{
    int minVal = INF;
    int minIndex = -1;
    for ( int v=0; v<n; v++ )
    {
        if( visited[v] == false and dist[v] < minVal )
        {
            minVal = dist[v];
            minIndex = v;
        }
    }
    return minIndex;
}

void Dijkstra ( int src, int n )
{
    int dist[MAX] ;
    bool visited [MAX];

    for ( int i=0; i<n; i++ )
    {
        dist[i] = INF;
        visited [i] = false;
        parent[i] = -1;
    }
    dist[src] = 0;

    for( int count = 0; count<n-1; count++ )
    {
        int u= minDistance( dist, visited, n );

        if ( u==-1 )  break;

        visited[u] = true;
        for ( int v=0; v<n; v++ )
        {
            if (visited[v] == false and graph [u][v]!= INF and dist[u]+graph[u][v]<dist[v] )
            {
                dist[v] = dist[u] + graph[u][v];
                parent[v] = u;
            }
        }
    }
    cout << "Shortest distances from Sources " << src << ":\n";
    for ( int i=0; i<n; i++)
    {
        cout << "To "<< i << " = " << dist[i] << "\n";
    }
}

void printPath( int dest )
{
    if ( parent[dest] == -1 )
    {
        cout << dest << " ";
        return;
    }
    printPath( parent[dest]);
    cout << dest << " ";
}


int main ()
{
    int n=5;
    int Graph( n );

    addEdges( 0, 1, 10);
    addEdges( 0, 4, 5);
    addEdges( 1, 2, 1);
    addEdges( 1, 4, 2);
    addEdges( 2, 3, 4);
    addEdges( 3, 0, 7);
    addEdges( 3, 2, 6);
    addEdges( 4, 2, 9);
    addEdges( 4, 3, 2);

    int src = 0;
    Dijkstra( src, n );

    int dest = 3;
    cout << "\nPath from " << src << " to " << dest << " : ";
    printPath( dest );

    cout << "\nCost = (see above output)\n";


    return 0;
}



